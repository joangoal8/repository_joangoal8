package org.tech.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue; //Autoincreasing id
import javax.persistence.GenerationType;

/*
 * Entity bean with JPA annotations
 * Hibernate provides JPA implementation 6DBTUFBJYRLMWW
 */
@Entity
@Table(name="User")
public class User {
	
	@Id
	@Column(name="email")
	private String email;
	
	private String pwd;
	
	private String firtsName;
	
	private String LastName;
	
	public String getEmail(){
		return this.email;
	}
	
	public void setPassword(String password){
		this.pwd = password;
	}
	
	public String getFirstName(){
		return this.firtsName;
	}
	
	public void setFirstName(String name){
		this.firtsName = name;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}
	
}
