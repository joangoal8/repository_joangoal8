package org.tech.model;

public class Pet {

}
