package org.tech.dao;

public class PetDAOImpl {

}
