package org.tech.dao;

public interface PetDAO {

}
